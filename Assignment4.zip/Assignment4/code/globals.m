SPSSTEREO_PATH = 'code/spsstereo';
DATA_DIR = 'data';
DETECTOR_DIR = fullfile(DATA_DIR, 'detectors');